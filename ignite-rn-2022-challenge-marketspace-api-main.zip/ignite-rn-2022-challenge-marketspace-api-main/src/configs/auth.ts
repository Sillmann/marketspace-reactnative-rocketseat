export const authConfig = {
  jwt: {
    secret: "ignite-rn-2022-challenge03-marketspace",
    expiresIn: "1d"
  },
};